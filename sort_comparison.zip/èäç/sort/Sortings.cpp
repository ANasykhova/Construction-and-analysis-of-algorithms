#ifndef SORTINGS_H
#define SORTINGS_H


#include <vector>
#include <utility>

class Sortings {
private:
    /**
     * Бинарный поиск.
     * @param numbers вектор, в котором ищем значение.
     * @param element искомое значение.
     * @param left левая граница поиска.
     * @param right правая граница поиска.
     * @return индекс для вставки.
     */
    static int binarySearch(const std::vector<int>* numbers, int element, int left, int right) {
        while (left <= right) {
            int middle = (left + right) >> 1;
            if (element < (*numbers)[middle]) {
                right = middle - 1;
            } else {
                left = middle + 1;
            }
        }
        return left;
    }

    /**
     * Поиск цифры в 256 системе счисления, стоящей на i разряде.
     * @param a число, в котором считаем ищем цифру.
     * @param i разряд.
     * @return цифра, стоящая на i месте в числе в 256 системе счисления.
     */
    static int countingDigit(int a, int i) {
        while (i != 1) {
            a /= 256;
            --i;
        }
        return a % 256;
    }

    /**
     * Слияние подвекторов с сортирвкой по неубыванию.
     * @param numbers сортируемый вектор.
     * @param begin начало первого подвектора.
     * @param middle начало второго подвектора.
     * @param end конец второго подвектора.
     */
    static void mergeLists(std::vector<int>* numbers, int begin, int middle, int end) {
        int left_size = middle - begin + 1, right_size = end - middle, index_current;
        std::vector<int> left(left_size);
        std::vector<int> right(right_size);

        for (int i = 0; i < left_size; ++i) {
            left[i] = (*numbers)[begin + i];
        }

        for (int i = 0; i < right_size; ++i) {
            right[i] = (*numbers)[middle + i + 1];
        }

        int index_left = 0, index_right = 0;
        for (index_current = begin; index_left < left_size && index_right < right_size;
             ++index_current) {
            if (left[index_left] < right[index_right]) {
                (*numbers)[index_current] = left[index_left++];
            } else {
                (*numbers)[index_current] = right[index_right++];
            }
        }

        for (; index_left < left_size; ++index_left) {
            (*numbers)[index_current] = left[index_left];
            ++index_current;
        }
        for (; index_right < right_size; ++index_right) {
            (*numbers)[index_current] = right[index_right];
            ++index_current;
        }
    }

    /**
     * Создание и перестроение кучи.
     * @param numbers сортируемый вектор.
     * @param root номер корня пирамиды.
     * @param bound правая граница в пирамиде.
     */
    static void fixHeap(std::vector<int>* numbers, int root, int bound) {
        while (2 * root <= bound) {
            int larger_child = 2 * root;
            if (larger_child < bound && (*numbers)[larger_child + 1] >= (*numbers)[larger_child]) {
                larger_child++;
            }

            if ((*numbers)[root] >= (*numbers)[larger_child]) {
                break;
            } else {
                std::swap((*numbers)[root], (*numbers)[larger_child]);
                root = larger_child;
            }
        }
    }

    /**
     * Разбиение Хоара (серединный опорный).
     * @param numbers сортируемый вектор.
     * @param left левая граница сортировки.
     * @param right правая граница сортировки.
     * @return Индекс пивота.
     */
    static int partitionHoare(std::vector<int>* numbers, int* left, int* right) {
        int pivot = (*numbers)[((*left) + (*right)) >> 1];
        while ((*left) <= (*right)) {
            while ((*numbers)[(*left)] < pivot) {
                (*left)++;
            }
            while ((*numbers)[(*right)] > pivot) {
                (*right)--;
            }
            if ((*left) >= (*right)) {
                break;
            }
            std::swap((*numbers)[(*right)--], (*numbers)[(*left)++]);
        }
        return (*right);
    }

    /**
     * Быстрая сортировка с разбиением Хоара.
     * @param numbers сортируемый вектор.
     * @param start левая граница сортировки.
     * @param end правая граница сортировки.
     */
    static void qSortHoare(std::vector<int>* numbers, int start, int end) {
        if (start < end) {
            int left = start, right = end;
            int pivot = partitionHoare(numbers, &left, &right);
            if (left != right) {
                qSortHoare(numbers, start, pivot);
                qSortHoare(numbers, pivot + 1, end);
            } else {
                qSortHoare(numbers, start, pivot - 1);
                qSortHoare(numbers, pivot + 1, end);
            }
        }
    }

    /**
     * Разбиение Ломуто (последний опорный).
     * @param numbers сортируемый вектор.
     * @param left левая граница сортировки.
     * @param right правая граница сортировки.
     * @return Индекс пивота.
     */
    static int partitionLomuto(std::vector<int>* numbers, int left, int right) {
        int pivot = (*numbers)[right];
        int index_pivot = left;
        for (int j = left; j <= right - 1; ++j) {
            if ((*numbers)[j] <= pivot) {
                std::swap((*numbers)[index_pivot], (*numbers)[j]);
                ++index_pivot;
            }
        }

        std::swap((*numbers)[right], (*numbers)[index_pivot]);
        return index_pivot;
    }

    /**
     * Быстрая сортировка с разбиением Ломуто.
     * @param numbers сортируемый вектор.
     * @param start левая граница сортировки.
     * @param end правая граница сортировки.
     */
    static void qSortLomuto(std::vector<int>* numbers, int start, int end) {
        if (start < end) {
            int pivot = partitionLomuto(numbers, start, end);
            qSortLomuto(numbers, start, pivot - 1);
            qSortLomuto(numbers, pivot + 1, end);
        }
    }

public:
    /**
     * Сортировка выбором.
     * @param numbers сортируемый вектор.
     * @param size размер вектора.
     */
    static void selectionSort(std::vector<int>* numbers, int size) {
        for (int index = 0; index < size - 1; ++index) {
            int min = index;
            bool flag = false;
            for (int j = index + 1; j < size; ++j) {
                if ((*numbers)[j] < (*numbers)[min]) {
                    min = j;
                    flag = true;
                }
            }
            if (flag) {
                std::swap((*numbers)[index], (*numbers)[min]);
            }
        }
    }

    /**
     * Сортировка пузырьком.
     * @param numbers сортируемый вектор.
     * @param size размер вектора.
     */
    static void bubbleSort(std::vector<int>* numbers, int size) {
        for (int i = 0; i < size - 1; ++i) {
            for (int j = 0; j < size - i - 1; ++j) {
                if ((*numbers)[j] > (*numbers)[j + 1]) {
                    std::swap((*numbers)[j], (*numbers)[j + 1]);
                }
            }
        }
    }

    /**
     * Сортировка пузырьком с условием Айверсона 1.
     * @param numbers сортируемый вектор.
     * @param size размер вектора.
     */
    static void bubbleSortIverson1(std::vector<int>* numbers, int size) {
        int i = 0;
        bool flag = true;
        while (flag) {
            flag = false;
            for (int j = 0; j + i < size - 1; ++j) {
                if ((*numbers)[j] > (*numbers)[j + 1]) {
                    flag = true;
                    std::swap((*numbers)[j], (*numbers)[j + 1]);
                }
            }
            ++i;
        }
    }

    /**
     * Сортировка пузырьком с условием Айверсона 1 и 2.
     * @param numbers сортируемый вектор.
     * @param size размер вектора.
     */
    static void bubbleSortIverson12(std::vector<int>* numbers, int size) {
        int i = 0;
        bool flag = true;
        while (flag) {
            flag = false;
            for (int j = 0; j + i < size - 1; ++j) {
                if ((*numbers)[j] > (*numbers)[j + 1]) {
                    flag = true;
                    std::swap((*numbers)[j], (*numbers)[j + 1]);
                }
            }
            ++i;
        }
    }

    /**
     * Сортировка простыми вставками.
     * @param numbers сортируемый вектор.
     * @param size размер вектора.
     */
    static void insertionSort(std::vector<int>* numbers, int size) {
        for (int index_j = 1; index_j < size; ++index_j) {
            int key = (*numbers)[index_j];
            int i = index_j - 1;
            while (i >= 0 && (*numbers)[i] > key) {
                (*numbers)[i + 1] = (*numbers)[i];
                --i;
            }

            (*numbers)[i + 1] = key;
        }
    }

    /**
     * Сортировка бинарными вставками.
     * @param numbers сортируемый вектор.
     * @param size размер вектора.
     */
    static void binaryInsertionSort(std::vector<int>* numbers, int size) {
        for (int i = 1; i < size; ++i) {
            int j = i - 1;
            int temp = (*numbers)[i];
            int k = binarySearch(numbers, (*numbers)[i], 0, j);
            while (j >= k) {
                (*numbers)[j + 1] = (*numbers)[j];
                --j;
            }
            (*numbers)[j + 1] = temp;
        }
    }

    /**
     * Сортировка подсчетом.
     * @param numbers сортируемый вектор.
     * @param size размер вектора.
     */
    static void countingSort(std::vector<int>* numbers, int size) {
        int min = (*numbers)[0], max = (*numbers)[0];
        // Находим диапазон чисел по минимуму и максимуму вектора.
        for(int i = 1; i < size; ++i) {
            if ((*numbers)[i] < min) {
                min = (*numbers)[i];
            }
            if ((*numbers)[i] > max) {
                max = (*numbers)[i];
            }
        }

        std::vector<int> counts(max - min + 1);
        for (int i = 0; i < size; ++i) {
            ++counts[(*numbers)[i] - min];
        }

        for (int i = 1; i < max - min + 1; ++i) {
            counts[i] += counts[i - 1];
        }

        //Отсортированный вектор.
        std::vector<int> sorted(size);

        for (int i = size - 1; i >= 0; --i) {
            --counts[(*numbers)[i] - min];
            sorted[counts[(*numbers)[i] - min]] = (*numbers)[i];
        }

        // Копируем отсортированный вектор в исходный.
        (*numbers) = sorted;
    }

    /**
     * Цифровая сортировка.
     * @param numbers сортируемый вектор.
     * @param size размер вектора.
     */
    static void radixSort(std::vector<int>* numbers, int size) {
        int k = 256;
        int max = (*numbers)[0];
        for (int i = 0; i < size; ++i) {
            if (max < (*numbers)[i]) {
                max = (*numbers)[i];
            }
        }

        int max_digit = 0;
        while (max != 0) {
            max /= 256;
            ++max_digit;
        }
        for (int index = 1; index < max_digit + 1; ++index) {
            std::vector<int> counts(2 * k);

            int digit;
            for (int j = 0; j < size; ++j) {
                digit = countingDigit((*numbers)[j], index);
                ++counts[256 + digit];
            }

            for (int j = 1; j < 2 * k; ++j) {
                counts[j] += counts[j - 1];
            }

            std::vector<int> sorted(size);
            for (int j = size - 1; j >= 0; --j) {
                digit = countingDigit((*numbers)[j], index);
                --counts[256 + digit];
                sorted[counts[256 + digit]] = (*numbers)[j];
            }
            (*numbers) = sorted;
        }
    }

    /**
     * Сортивка слиянием.
     * @param numbers сортируемый вектор.
     * @param length размер вектора.
     */
    static void mergeSort(std::vector<int>* numbers, int length) {
        int size = 1;
        while (size < length) {
            for (int i = 0; i < length; i += 2 * size) {
                int middle = std::min(i + size - 1, length - 1);
                int end = std::min(i + 2 * size - 1, length - 1);
                mergeLists(numbers, i, middle, end);
            }
            size *= 2;
        }
    }

    /**
     * Обертка быстрой сортировки с разбиением Хоара для более удобного обращения.
     * @param numbers сортируемый вектор.
     * @param size размер вектора.
     */
    static void quickSortHoare(std::vector<int>* numbers, int size) {
        qSortHoare(numbers, 0, size - 1);
    }

    /**
     * Обертка быстрой сортировки с разбиением Ломуто для более удобного обращения.
     * @param numbers сортируемый вектор.
     * @param size размер вектора.
     */
    static void quickSortLomuto(std::vector<int>* numbers, int size) {
        qSortLomuto(numbers, 0, size - 1);
    }

    /**
     * Пирамидальная сортировка.
     * @param numbers сортируемый вектор.
     * @param size размер вектора.
     */
    static void heapSort(std::vector<int>* numbers, int size) {
        for (int i = size / 2; i >= 0; --i) {
            fixHeap(numbers, i, size - 1);
        }

        for (int i = size - 1; i >= 0; --i) {
            std::swap((*numbers)[0], (*numbers)[i]);
            fixHeap(numbers, 0, i - 1);
        }
    }
};

#endif
