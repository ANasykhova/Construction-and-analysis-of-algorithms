#include <vector>
#include <cstdlib>
#include "Sortings.cpp"

class Generator {
private:
    // Вектор с элементами от 0 до 5.
    std::vector<int> arrFrom0to5;
    // Вектор с элементами от 0 до 4000.
    std::vector<int> arrFrom0to4000;
    // Почти отсортированный вектор.
    std::vector<int> almostSortedArr;
    // Обратно отсортированный вектор.
    std::vector<int> reverseSortArr;

    /**
     * Разворот вектора.
     * @param numbers исходный вектор.
     */
    static void reverse(std::vector<int>* numbers) {
        std::vector<int> reverse_vector(4100);
        for (int i = 0, j = 4099; i < 4100; ++i, --j) {
            reverse_vector[j] = (*numbers)[i];
        }

        for (int i = 0; i < 4100; ++i) {
            (*numbers)[i] = reverse_vector[i];
        }
    }

    /**
     * Перемешивание вектора.
     * @param numbers исходный вектор.
     */
    static void shuffle(std::vector<int>* numbers) {
        for (int i = 0; i < 4100 / 50; ++i) {
            int index1 = std::rand() % 50;
            int index2 = std::rand() % 50;
            std::swap((*numbers)[index1 + i * 50], (*numbers)[index2 + i * 50]);
        }
    }

    /**
     * Создание вектора.
     * @param reverseSort обратно отсортированный вектор;
     * @param almostSorted почти отсортированный вектор;
     * @param from0to4000 вектор с элементами от 0 до 4000;
     * @return указатель на вектор удовлетворяющий переданным настройкам.
     */
    static std::vector<int> createVector(bool reverseSort, bool almostSorted, bool from0to4000) {
        std::vector<int> numbers(4100);

        if (reverseSort || almostSorted) {
            int j = 1;
            for (int i = 0; i < 4100; ++i) {
                numbers[i] = j++;
            }
            Sortings::quickSortHoare(&numbers, 4100);

            if (reverseSort) {
                reverse(&numbers);
            }
            if (almostSorted) {
                shuffle(&numbers);
            }
        } else {
            int maxVal = 5;
            if (from0to4000){
                maxVal = 4000;
            }
            for (int i = 0; i < 4100; ++i) {
                numbers[i] = std::rand() % (maxVal + 1);
            }
        }

        return numbers;
    }

    /**
     * Копирует значения из одного вектора в другой.
     * @param from вектор, из которого копируем.
     * @param to вектор, в который копируем.
     * @param size количество элементов, которые нужно скопировать.
     */
    static void copy (const std::vector<int>* from, std::vector<int>* to, int size) {
        for (int i = 0; i < size; ++i){
            (*to)[i] = (*from)[i];
        }
    }

public:
    /**
     * Создает генератор векторов.
     */
    Generator() {
        arrFrom0to5 = createVector(false, false, false);
        arrFrom0to4000 = createVector(false, false, true);
        almostSortedArr = createVector(false, true, false);
        reverseSortArr = createVector(true, false, false);
    }

    /**
     * Возвращает копию вектора нужного типа.
     * @param i тип вектора.
     * @return копия вектора нужного размера и типа.
     */
    void getArr(int i, std::vector<int>* arr, int size) {
        switch (i) {
            case 0:
                copy(&arrFrom0to5, arr, size);
                return;
            case 1:
                copy(&arrFrom0to4000, arr, size);
                return;
            case 2:
                copy(&reverseSortArr, arr, size);
                return;
            case 3:
                copy(&almostSortedArr, arr, size);
                return;
            default:
                return;
        }
    }
};
