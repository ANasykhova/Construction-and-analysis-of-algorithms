#include <vector>
#include <map>
#include <fstream>
#include <iostream>
#include "Tester.cpp"
#include "Sortings.cpp"

/* ПиАА 2022
 * Насыхова Анастасия Артемовна БПИ-203
 * Среда разработки: Clion.
 *
 * Релизовано:
 * + Реализация 12 сортировок с комментариями;
 * + Генерация последовательностей в вектор;
 * + Измерение времени;
 * + Вывод результатов в *.csv;
 * + Использование указателей на функции;
 * + Тестирование сортировок;
 * + input и output для тестов;
 * + Проверка упорядоченности массива после сортировки;
 * + Файл с неверными результатами сортировки;
 *
 * + Результаты измерений в Excel;
 * + Необходимые графики с подписями;
 *
 * + Отчет о результатах анализа.
 *
 * Не реализовано: кажется, что все есть)
 *
 */

int main() {
    // Указатели на функции.
    std::map<std::string, void (*)(std::vector<int>*, int)> sortings = {
            {"Select Sort", Sortings::selectionSort},
            {"Bubble Sort", Sortings::bubbleSort},
            {"Bubble Sort + Iverson 1", Sortings::bubbleSortIverson1},
            {"Bubble Sort + Iverson 1&2", Sortings::bubbleSortIverson12},
            {"Insertion Sort", Sortings::insertionSort},
            {"Binary Insertion Sort", Sortings::binaryInsertionSort},
            {"Counting Sort", Sortings::countingSort},
            {"Radix Sort", Sortings::radixSort},
            {"Merge Sort", Sortings::mergeSort},
            {"Quick Sort Hoare", Sortings::quickSortHoare},
            {"Quick Sort Lomuto", Sortings::quickSortLomuto},
            {"Heap Sort", Sortings::heapSort}
    };

    // Виды массивов для сортировки.
    std::vector<std::string> methodsName = {
            "Random numbers 0-5",
            "Random numbers 0-4000",
            "Almost sort vector",
            "Reverse sort vector"
    };

    //Для вывода отсортированного вектора.
    std::string output = "output.txt";
    //Для вывода исходного вектора.
    std::string input = "input.txt";
    //Для неверно отсортированного вектора.
    std::string wa = "wa.txt";
    // *.csv файлы с результатами.
    std::string path1 = "table50-300.csv";
    std::string path2 = "table100-4100.csv";

    std::fstream fs1, fs2;
    fs1.open(path1, std::fstream::out);
    fs2.open(path2, std::fstream::out);

    if (fs1.is_open() && fs2.is_open()) {
        // Вывводим первые строки в таблицы.
        fs1 << "Method \\ Size;";
        fs2 << "Method \\ Size;";
        for (int i = 50; i <= 300; i += 10) {
            fs1 << i << ";";
        }
        for (int i = 100; i <= 4100; i += 100) {
            fs2 << i << ";";
        }
        fs1 << "\n";
        fs2 << "\n";

        // Тестировщик.
        Tester tester(input, output, wa);
        // Генератор векторов.
        Generator creator;

        for (auto &sorting : sortings) { // Проходимся по сортировкам.
            std::cout << sorting.first << " is testing...\n";

            // Проверяем сортировку на разных типах векторов.
            for (int i = 0; i < 4; ++i) {
                std::string sortingName = sorting.first;
                fs1 << sortingName << ";" << methodsName[i] << ";";
                fs2 << sortingName << ";" << methodsName[i] << ";";

                // Тестируем сортировку на массиве размером от 50 до 300.
                for (int j = 50; j <= 300; j += 10) {
                    auto tact = tester.test(creator, i, sortingName, j, sorting.second);
                    fs1 << tact << ";";
                }
                fs1 << "\n";

                //Тестируем сортировку на массиве размером от 100 до 4100
                for (int j = 100; j <= 4100; j += 100) {
                    auto tact = tester.test(creator, i, sortingName, j,sorting.second);
                    fs2 << tact << ";";
                }
                fs2 << "\n";
            }
        }
    } else {
        std::cout << "Can\'t open file " << path1 << " or " << path2 << "\n";
    }
    return 0;
}
