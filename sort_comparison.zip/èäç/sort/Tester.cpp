#include <fstream>
#include <chrono> // для вычисления времени
#include <iostream>
#include "Generator.cpp"

class Tester {
private:
    //Для вывода исходного массива в файл.
    std::fstream fin;

    //Для вывода отсортированных массивов.
    std::fstream fout;

    //Для вывода ошибочных сортировок.
    std::fstream fwa;

    typedef std::chrono::high_resolution_clock Clock;

    /**
     * Проверяет правильность сортировки вектора.
     * @param numbers проверяемый вектор.
     * @param size размер проверяемого вектора.
     * @return True - вектора отсортирован верно; False - неверно.
     */
    static bool checkSort(const std::vector<int>& numbers, int size) {
        for (int i = 1; i < size; ++i) {
            if (numbers[i] < numbers[i - 1]) {
                return false;
            }
        }
        return true;
    }

    /**
     * Выводит вектор и название сортировки.
     * @param fs поток для вывода информации в файл.
     * @param sortName название сортировки.
     * @param numbers вектор.
     * @param size размер вектора.
     */
    static void writeArr(std::fstream& fs, std::string& sortName, const std::vector<int>* numbers, int size) {
        if (fs.is_open()) {
            fs << sortName << ":\n";
            for (int i = 0; i < size; ++i) {
                fs << (*numbers)[i] << " ";
            }
            fs << "\n\n";
        }
    }

public:
    /**
     * Создает тестировщик.
     * @param inputFile файл для вывода исходного вектора.
     * @param outputFile файл для вывода отсортированного вектора.
     * @param waFile файл для вывода неверно отсортированного вектора.
     */
    Tester(std::string &inputFile, std::string &outputFile, std::string &waFile) {
        fin.open(inputFile, std::ios::out);
        if (!fin.is_open()) std::cout << "Tester: can\'t open input file";

        fout.open(outputFile, std::ios::out);
        if (!fout.is_open()) std::cout << "Tester: can\'t open output file";

        fwa.open(waFile, std::ios::out);
        if (!fwa.is_open()) std::cout << "Tester: can\'t open wa file";
    }

    /**
     * Тестирование сортировок.
     * @param creator генератор вектора.
     * @param kindOfArr тип генерируемого вектора.
     * @param sortingName название сортировки.
     * @param f функция сортировки.
     * @return среднее количество тактов, нужных для выполнения сортировки.
     */
    auto test(Generator& creator, int kindOfArr, std::string& sortingName, int size, void (*f)(std::vector<int>*, int)) {
        // Суммарное время.
        auto sum = 0;

        for (int i = 0; i < 33; ++i) {
            std::vector<int> numbers(size);
            creator.getArr(kindOfArr, &numbers, size);

            if (i <= 3) { // Первые 3 сортировки не учитываем в итоге.
                (*f)(&numbers, size);
            }
            else {
                // Замеряем время выполнения.
                auto t1 = Clock::now();
                (*f)(&numbers, size);
                auto t2 = Clock::now();
                sum += std::chrono::duration_cast<std::chrono::nanoseconds>
                        (t2 - t1).count();

                // Выводим результаты сортировки в файл.
                if (i == 32) {
                    std::vector<int> inputArr(size);
                    creator.getArr(kindOfArr, &inputArr, size);

                    writeArr(fin, sortingName, &inputArr, size);

                    // Проверяем правильность сортировки.
                    if (!checkSort(numbers, size)) {
                        writeArr(fwa, sortingName, &numbers, size);
                    } else {
                        writeArr(fout, sortingName, &numbers, size);
                    }
                }
            }
        }
        // Определяем среднее время сортировки.
        return sum / 30;
    }

    ~Tester() {
        // Закрываем потоки.
        fin.close();
        fout.close();
        fwa.close();
    }
};